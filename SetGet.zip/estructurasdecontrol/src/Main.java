import static java.lang.System.*;

public class Main {
    public static void main(String[] args) {
        Persona Persona1 = new Persona();
        Persona1.setNombre("Raúl");
        Persona1.setEdad(25);
        Persona1.setNumeroTelefono(661661661);


        Persona Persona2= new Persona();
        Persona2.setNombre("Elena");
        Persona2.setEdad(50);
        Persona2.setNumeroTelefono(662662662);

        Persona Persona3 = new Persona ();
        Persona3.setNombre("Carmen");
        Persona3.setEdad(27);
        Persona3.setNumeroTelefono(663663663);

       

        System.out.println(Persona1.getNombre() + " " + Persona1.getEdad() + " " + Persona1.getNumeroTelefono());
        System.out.println(Persona2.getNombre() + " " + Persona2.getEdad() + " " + Persona2.getNumeroTelefono());
        System.out.println(Persona3.getNombre() + " " + Persona3.getEdad() + " " + Persona3.getNumeroTelefono());

;    }
}







        class Persona{
        private String Nombre;
        private int Edad;

        private int NumeroTelefono;

        public void setNombre (String Nombre){
                this.Nombre=Nombre;
            }
        public void setEdad(int Edad){
            this.Edad=Edad;
        }

        public void setNumeroTelefono(int NumeroTelefono){
            this.NumeroTelefono=NumeroTelefono;
        }
        public String getNombre(){
            return this.Nombre;
        }

        public int getEdad(){
                return this.Edad;
            }
        public int getNumeroTelefono()
        {
            return this.NumeroTelefono;
        }
        }
